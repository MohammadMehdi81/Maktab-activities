import time

class BirthDay:
    def __init__(self, birthhours, birthday, birthmounth, birthyear):
        self.birthday = birthday
        self.birthmounth = birthmounth
        self.birthyear = birthyear
        self.birthhours = birthhours

    def time_to_birthday(self):
        live_date = time.localtime()

        if live_date.tm_mon <= self.birthmounth:
            mounth = self.birthmounth - live_date.tm_mon -1
        else:
            mounth = (12 - live_date.tm_mon) + self.birthmounth - 1

        if live_date.tm_mday <= self.birthday:
            days = self.birthday - live_date.tm_mday - 1
        else:
            days = (30 - live_date.tm_mday) + self.birthday - 1

        if live_date.tm_hour <= self.birthhours:
            hours = self.birthhours - live_date.tm_hour
        else:
            hours = (24 - live_date.tm_hour) + self.birthhours

        print(mounth, " mounth", ' / ', days, ' day', ' / ',hours, ' hour')


    def age(self):
        live_date = time.localtime()
        year = live_date.tm_year - self.birthyear - 2

        daysb = self.birthmounth * 30 + 6 + self.birthday
        daysn = live_date.tm_yday

        days = daysn + (365 - daysb)

        if days >= 365:
            year += 1
            days -= 365

        hours = days * 24 + live_date.tm_hour

        print(year, " year", '\t', hours, ' hours')
        return f'years: {year} \ hours:{hours}'


mohammad = BirthDay(0, 15, 5, 2002)
mohammad.time_to_birthday()
mohammad.age()
