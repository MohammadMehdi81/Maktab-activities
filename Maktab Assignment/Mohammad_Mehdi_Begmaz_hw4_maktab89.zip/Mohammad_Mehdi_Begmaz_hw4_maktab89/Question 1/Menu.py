import User


def Main_Menu():
    menu_items = [
        'exit',
        'Register User',
        'Login',
    ]

    line = "-" * 22

    while True:
        print("\n\n-------- Menu --------")

        for index, value in enumerate(menu_items):
            print(index + 1, value)
        print(line)

        try:
            user_number = int(input("> "))
            if user_number == 1:
                print("Bye!")
                break
            func = menu_items[user_number - 1]
            func = func.replace(" ", "_")

            eval(f"User.{func}()")

        # except (ValueError, IndexError):
        #     input("Error !!! \ninvalid key! \n\nPress enter to back main ... ")

        except AssertionError as msg:
            input(msg)
            eval(f"{func}()")


def Menu_Login(User):
    menu_items = [
        'Information',
        'Change user information',
        'Change password',
        'exit',
    ]

    line = "-" * 22

    while True:
        print("\n\n-------- Menu --------")

        for index, value in enumerate(menu_items):
            print(index + 1, value)
        print(line)

        try:
            user_number = int(input("> "))
            if user_number == 4:
                print("Bye!")
                break
            func = menu_items[user_number - 1]
            func = func.replace(" ", "_")

            eval(f"{User.func}({User})")

        # except (ValueError, IndexError):
        #     input("Error !!! \ninvalid key! \n\nPress enter to back main ... ")

        except AssertionError as msg:
            input(msg)
            eval(f"{func}()")
