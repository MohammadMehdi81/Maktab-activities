import Menu

class User:

    max_id = 20
    used_id = 0
    Users = {}

    def __init__(self, username, password, phonenumber = None):
        self.username = username
        self.phonenumber = phonenumber
        if len(password) < 4:
            raise 'Your password must contain at least 4 characters!!!'
        else:
            self.__password = password

        if User.used_id < User.max_id:
            self.id_number = User.used_id + 1
            User.used_id += 1
        else:
            raise 'You pass from limitation of maximum id numbers!!!'

    @classmethod
    def Register_User(self):
        if User.used_id > User.max_id:
            print('Raise maximum number if id!!!')
        else:
            username = input('Enter your username: ')
            password = input('Enter your password: ')
            assert len(password) >= 4, 'Your password must contain at least 4 characters!!!'
            flag = input('Do you want to write phone number?(Yes/No)')
            if flag == 'Yes':
                phonenumber = input('Enter your phone number: ')
                a = User(username, password, phonenumber)
            else:
                a = User(username, password)

            print('User succesfuly created!!!')
            User.Users[username] = a

    def Check_User(self, user):
        if user.username in User.Users.keys():
            a = User.Users[user.username]
            if a.password == user.__password:
                print('You login succesfuly!!!')
                return True
            else:
                print('Wrong Password!!!')
                return False
        else:
            print("This user is not exist!!!")
            return False

    def __str__(self):
        return f'username: {self.username}/ phone number: {self.phonenumber}/ id number: {self.id_number}'

    def Information(self, User):
        print(str(User))

    def Change_user_information(self, user):
        username = input('Enter your new username: ')
        assert username not in User.Users.keys(), 'Your username already exist!!!'
        if username not in User.Users.keys():
            user.username = username
            flag = input('Do you want to write phone number?(Yes/No)')
            if flag == 'Yes':
                phonenumber = input('Enter your new phone number: ')
                user.phonenumber = phonenumber
            print('succesfuly changing information!!!')

    @staticmethod
    def set_password(user, password):
        user.__password = password
        print('password change succesfuly!!!')


    def Change_password(self, user):
        previos_password = input('Enter your previos password: ')
        assert len(previos_password) >= 4, 'Your password must contain at least 4 characters!!!'
        if previos_password == user.__password:
            print('Your password was ture!!!')
            new_password = input('Enter your new password: ')
            assert len(previos_password) >= 4, 'Your password must contain at least 4 characters!!!'
            repeat_password = input('repeat your new password: ')
            assert repeat_password == new_password, "repeat password doesnt match with new password!!!"
            if new_password == repeat_password:
                User.set_password(user, new_password)
            else:
                print("repeat password doesnt match with new password!!!")

    def Login(self):
        username = input('Enter your username: ')
        password = input('Enter your password: ')
        b = User(username, password)
        if User.Check_User(b) == True:
            Menu.Menu_Login(User)