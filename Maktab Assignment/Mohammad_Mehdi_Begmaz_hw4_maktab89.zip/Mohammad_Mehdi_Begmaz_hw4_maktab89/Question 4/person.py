class person:
    def __init__(self, name, email, sex):
        self.name = name
        self.email = email
        self.sex = sex

class writer(person):
    def __init__(self, writer_code, ganr):
        super().__init__()
        self.writer_code = writer_code
        self.ganr = ganr

class shaier(person):
    def __init__(self, sabk):
        super().__init__()
        self.sabk = sabk

class researcher(person):
    def __init__(self, reshte, university):
        super().__init__()
        self.university = university
        self.reshte = reshte

# ---------------------------------------------

class asar:
    def __init__(self, name, saheb):
        self.name = name
        self.saheb = saheb

class ketab(asar):
    def __init__(self, shabak, entesharat):
        super().__init__()
        self.shabak = shabak
        self.entesharat = entesharat

    def len_of_saheban(self):
        if isinstance(self.saheb, list):
            return len(self.saheb)
        return 1


class sher(asar):
    def __init__(self, ghaleb):
        super().__init__()
        if len(self.saheb) != 1:
            raise ('Sher just can has one saheb!!!')
        self.ghaleb = ghaleb

class article(asar):
    def __init__(self, magale, enteshar):
        super().__init__()
        self.magale = magale
        self.enteshar = enteshar

    def len_of_saheban(self):
        if isinstance(self.saheb, list):
            return len(self.saheb)
        return 1


