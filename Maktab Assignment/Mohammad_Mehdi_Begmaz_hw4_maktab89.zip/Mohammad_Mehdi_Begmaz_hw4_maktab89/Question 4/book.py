class book:
    def __init__(self, name, gheimat, tedad):
        self.name = name
        self.gheimat = gheimat
        if tedad > 0:
            self.tedad = tedad
        else:
            self.tedad = 0

    def __str__(self):
        return f'Name: {self.name}/ Gheimat: {self.gheimat}/ tedad: {self.tedad}'
