class BankAccount:

    __Min = 5000

    def __init__(self, name, balance):
        self.balance = balance
        self.name = name

    def bardasht(self, bardasht):
        if bardasht > (self.balance - self.__Min):
            print('Fail transaction!!!')
        else:
            self.balance -= bardasht
            print('Successful transaction!!!')

    def variz(self, variz):
        self.balance += variz
        print('Successful transaction!!!')

    def enteghal(self, BankAccount, mablagh):
        if mablagh > (self.balance - self.__Min):
            print('Fail transaction!!!')
        else:
            self.balance -= mablagh
            BankAccount.variz(mablagh)
            print('Successful transaction!!!')
