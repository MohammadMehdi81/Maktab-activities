def get_number1(string):
    list1 = string.split(" ")
    return float(list1[0])

def get_operation(string):
    list1 = string.split(" ")
    return list1[1]

def get_number2(string):
    list1 = string.split(" ")
    return float(list1[2])
